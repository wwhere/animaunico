
describe('pending', function(){
  it('should be allowed')
})